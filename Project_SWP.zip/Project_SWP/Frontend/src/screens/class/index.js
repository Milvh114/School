import ClassDetail from './ClassDetail.jsx'
import ClassManager from './ClassManager.jsx'


export { ClassDetail, ClassManager,}
