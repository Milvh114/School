import Auth from './Auth.jsx'
import Blank from './Blank.jsx'
import Dashboard from './Dashboard.jsx'
import Profile from './Profile.jsx'
import Password from './Password.jsx'

export { Auth, Blank, Dashboard, Profile, Password}
