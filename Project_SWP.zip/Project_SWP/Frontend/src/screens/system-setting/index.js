import NewSystemSetting from './NewSystemSetting.jsx'
import SystemSettingDetail from './SystemSettingDetail.jsx'
import SystemSettingEdit from './SystemSettingEdit.jsx'
import SystemSettingManager from './SystemSettingManager.jsx'

export {
  NewSystemSetting,
  SystemSettingDetail,
  SystemSettingEdit,
  SystemSettingManager,
}

