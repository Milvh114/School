const dataAssignment = [
  {
    id: 1,
    title: "Lab1",
    description: "Vision and Scope",
    subject: "SWR302",
    creator: "ThangPD",
    date: "02/10/2023",
  },
  {
    id: 2,
    title: "Ass2",
    description: "afdas",
    subject: "SWT301",
    creator: "NangNTH",
    date: "02/10/2023",
  },
  {
    id: 9,
    creatorName: "Thanh LM",
    subjectName: "ABCD",
    title: "vhghvhgh234vhgh234",
    description: "hgff",
    date: "2023-10-17T10:46:20.060+00:00",
  },
];

export default dataAssignment;
