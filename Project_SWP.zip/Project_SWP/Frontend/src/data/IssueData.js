const dataIssue = [
  {
    id: '1',
    project: 'abc',
    namei: 'abc',
    identifier: 'minh thanh',
    type: 'Technical',
    modified: '10-09-2023',
    dueDate: '15-09-2023',
    status: 'in-progress',
    description: 'can not add student',
    priority: 'high',
    owner: 'dat'
  },
  {
    id: '2',
    namei: 'abc',
    project: 'abc',
    identifier: 'minh thanh',
    type: 'Technical',
    modified: '10-09-2023',
    dueDate: '15-09-2023',
    status: 'in-progress',
    description: 'can not add student',
    priority: 'high',
    owner: 'dat'
  }
]

export default dataIssue
