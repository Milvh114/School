const starStudent = [
  {
    id: 1,
    fullName: 'Alex',
    className: '10A',
    mobile: '097 3584 5870',
    address: '911 Deer Ridge Drive,USA',
    role: 'admin',
    mark: '1185',
    percentage: '98%',
    year: '2019'
  },
  {
    class_id: 'PRE2209',
    id: 2,
    fullName: 'John Smith',
    className: '10A',
    mobile: '097 3584 5870',
    address: '911 Deer Ridge Drive,USA',
    role: 'student',
    mark: '1185',
    percentage: '98%',
    year: '2019'
  },
  {
    class_id: 'PRE2209',
    id: 3,
    fullName: 'Jimmy',
    className: '10A',
    mobile: '097 3584 5870',
    address: '911 Deer Ridge Drive,USA',
    role: 'student',
    mark: '1185',
    percentage: '98%',
    year: '2019'
  },
  {
    class_id: 'PRE2209',
    id: 4,
    fullName: 'John Smith',
    className: '10A',
    mobile: '097 3584 5870',
    address: '911 Deer Ridge Drive,USA',
    role: 'student',
    mark: '1185',
    percentage: '98%',
    year: '2019'
  },
  {
    class_id: 'PRE2209',
    id: 5,
    fullName: 'jack',
    className: '10A',
    mobile: '097 3584 5870',
    address: '911 Deer Ridge Drive,USA',
    role: 'student',
    mark: '1185',
    percentage: '98%',
    year: '2019'
  }
]

export { starStudent }
