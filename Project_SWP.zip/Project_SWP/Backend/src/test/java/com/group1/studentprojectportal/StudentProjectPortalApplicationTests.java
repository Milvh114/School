package com.group1.studentprojectportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentProjectPortalApplicationTests {

    @Test
    void contextLoads() {
    }

}
