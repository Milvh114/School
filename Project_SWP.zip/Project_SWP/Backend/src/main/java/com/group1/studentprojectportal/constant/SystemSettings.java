package com.group1.studentprojectportal.constant;

public enum SystemSettings {
    SEMESTER,
    ROLE,
    PERMITTED_EMAIL_DOMAIN
}
