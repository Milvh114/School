package com.group1.studentprojectportal.constant;

public class AppContants {
    public static final String DEFAULT_PAGE_NUMBER = "0";
    public static final String DEFAULT_PAGE_SIZE = "10";
    public static final String DEFAULT_STATUS = "All Status";
    public static final String DEFAULT_ROLE = "All Role";
    public static final String DEFAULT_MANAGER = "";
    public static final String DEFAULT_NAME = "";
    public static final String DEFAULT_SORT_BY = "id";
    public static final String DEFAULT_ORDER = "descend";
    public static final Integer MAX_PAGE_SIZE = 20;

}
