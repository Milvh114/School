package com.group1.studentprojectportal.constant;

public enum Roles {
    ADMIN,
    SUBJECT_MANAGER,
    LECTURE,
    STUDENT
}

