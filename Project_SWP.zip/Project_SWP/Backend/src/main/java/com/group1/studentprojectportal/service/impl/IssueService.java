package com.group1.studentprojectportal.service.impl;

public class IssueService {
}
