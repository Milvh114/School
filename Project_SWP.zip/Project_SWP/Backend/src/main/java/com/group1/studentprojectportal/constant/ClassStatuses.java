package com.group1.studentprojectportal.constant;

public enum ClassStatuses {
    CANCELLED,
    COMPLETED,
    ONGOING,
    PENDING
}
