package com.group1.studentprojectportal.constant;

public enum SubjectSettings {
    WORK_COMPLEXITY_LEVELS,
    WORKLOADS,
    WORK_QUALITY_LEVELS
}
