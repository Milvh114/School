package com.group1.studentprojectportal.controller;

public class SubjectSettingController {

}
