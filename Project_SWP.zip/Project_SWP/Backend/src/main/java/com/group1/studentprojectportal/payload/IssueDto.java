package com.group1.studentprojectportal.payload;

public class IssueDto {
}
