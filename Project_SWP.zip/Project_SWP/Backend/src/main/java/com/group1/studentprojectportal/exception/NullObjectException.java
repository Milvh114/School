package com.group1.studentprojectportal.exception;

public class NullObjectException extends RuntimeException {

    public NullObjectException(String message) {
        super(message);
    }
}
