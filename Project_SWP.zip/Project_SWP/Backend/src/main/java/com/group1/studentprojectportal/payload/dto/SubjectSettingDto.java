package com.group1.studentprojectportal.payload.dto;

public class SubjectSettingDto {

}
