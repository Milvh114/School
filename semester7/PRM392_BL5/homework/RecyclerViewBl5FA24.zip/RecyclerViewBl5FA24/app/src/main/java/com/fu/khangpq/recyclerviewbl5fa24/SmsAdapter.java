package com.fu.khangpq.recyclerviewbl5fa24;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class SmsAdapter extends RecyclerView.Adapter<SmsViewHolder> {

    private List<Sms> data;

    public SmsAdapter(List<Sms> data) {
        this.data = data;
    }

    @NonNull
    @Override
    public SmsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View v = inflater.inflate(R.layout.sms_item, parent, false);
        return new SmsViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull SmsViewHolder holder, int position) {
        Sms sms = data.get(position);
        holder.setSms(sms);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }
}
