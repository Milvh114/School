package com.fu.khangpq.recyclerviewbl5fa24;

import android.content.Context;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class SmsViewHolder extends RecyclerView.ViewHolder {

    private TextView tvPhoneNumber;
    private TextView tvSmsContent;

    private void bindingView() {
        tvSmsContent = itemView.findViewById(R.id.tvSmsContent);
        tvPhoneNumber = itemView.findViewById(R.id.tvPhoneNumber);
    }

    private void bindingAction() {
        tvSmsContent.setOnClickListener(this::onTvSmsContentClick);
        tvPhoneNumber.setOnClickListener(this::onTvPhoneNumberClick);
        itemView.setOnClickListener(this::onItemClick);
    }

    private void onItemClick(View view) {
        Toast.makeText(itemView.getContext(), tvPhoneNumber.getText() + "---" + tvSmsContent.getText(), Toast.LENGTH_SHORT).show();
    }

    private void onTvPhoneNumberClick(View view) {
        Toast.makeText(itemView.getContext(), tvPhoneNumber.getText(), Toast.LENGTH_SHORT).show();
    }

    private void onTvSmsContentClick(View view) {
        Toast.makeText(itemView.getContext(), tvSmsContent.getText(), Toast.LENGTH_SHORT).show();
    }

    public SmsViewHolder(@NonNull View itemView) {
        super(itemView);
        bindingView();
        bindingAction();
    }

    public void setSms(Sms sms) {
        tvPhoneNumber.setText(sms.getPhoneNumber());
        tvSmsContent.setText(sms.getSmsContent());
    }
}
