package com.fu.khangpq.recyclerviewbl5fa24;

public class Sms {
    private String phoneNumber;
    private String smsContent;

    public Sms(String phoneNumber, String smsContent) {
        this.phoneNumber = phoneNumber;
        this.smsContent = smsContent;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getSmsContent() {
        return smsContent;
    }
    

}
