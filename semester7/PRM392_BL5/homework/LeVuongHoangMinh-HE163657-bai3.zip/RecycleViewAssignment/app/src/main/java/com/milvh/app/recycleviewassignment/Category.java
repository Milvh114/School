package com.milvh.app.recycleviewassignment;

public class Category {

    private int ImagePath;

    private String Name;


    public Category() {
    }

    public Category(int ImagePath, String Name) {
        this.ImagePath = ImagePath;
        this.Name = Name;
    }

    public int getImagePath() {
        return ImagePath;
    }

    public void setImagePath(int ImagePath) {
        this.ImagePath = ImagePath;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    @Override
    public String toString() {
        return Name;
    }
}
