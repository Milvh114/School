package com.milvh.app.recycleviewassignment;

import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.milvh.app.recycleviewassignment.databinding.ActivityMainBinding;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Category> catData;
    ActivityMainBinding binding;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        Data();
        initCategory();
    }


    private void initCategory() {
//        binding.progressBarCategory.setVisibility(View.VISIBLE);
//        ArrayList<Category> list = new ArrayList<>();
        if (catData.size() > 0) {
            binding.categoryView.setLayoutManager(new GridLayoutManager(MainActivity.this, 3));
            RecyclerView.Adapter adapter = new CategoryAdapter(catData);
            System.out.println("123"+ adapter);
            binding.categoryView.setAdapter(adapter);
        }
    }

    private void Data() {
        catData = new ArrayList<>();
        catData.add(new Category(R.drawable.cat1_xxhdpi, "pharmacy"));
        catData.add(new Category(R.drawable.cat2_xxhdpi, "registry"));
        catData.add(new Category(R.drawable.cat3_xxhdpi, "cartwhell"));
        catData.add(new Category(R.drawable.cat4_xxhdpi, "clothing"));
        catData.add(new Category(R.drawable.cat5_xxhdpi, "shoes"));
        catData.add(new Category(R.drawable.cat6_xxhdpi, "accessories"));
        catData.add(new Category(R.drawable.cat7_xxhdpi, "baby"));
        catData.add(new Category(R.drawable.cat8_xxhdpi, "home"));
        catData.add(new Category(R.drawable.cat9_xxhdpi, "patio & garden"));


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.option_menu, menu);
        return true;
    }
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.option_menu, menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.opt_search) {
            Toast.makeText(this, item.getTitle() + " onContextItemSelected", Toast.LENGTH_SHORT).show();
        } else if (id == R.id.opt_cart) {
            Toast.makeText(this, item.getTitle() + " onContextItemSelected", Toast.LENGTH_SHORT).show();
        }
//        else if (id == R.id.opt_logout) {
//            Toast.makeText(this, item.getTitle() + " onContextItemSelected", Toast.LENGTH_SHORT).show();
//        }
        return super.onContextItemSelected(item);
    }
    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.opt_search) {
            Toast.makeText(this, item.getTitle() + " onContextItemSelected", Toast.LENGTH_SHORT).show();
        } else if (id == R.id.opt_cart) {
            Toast.makeText(this, item.getTitle() + " onContextItemSelected", Toast.LENGTH_SHORT).show();
        }
//        else if (id == R.id.opt_logout) {
//            Toast.makeText(this, item.getTitle() + " onContextItemSelected", Toast.LENGTH_SHORT).show();
//        }
        return super.onContextItemSelected(item);
    }

}