package com.milvh.app.recycleviewassignment;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.milvh.app.recycleviewassignment.databinding.ActivityMainBinding;
import com.milvh.app.recycleviewassignment.databinding.ActivityProducDetailBinding;

public class ProducDetailActivity extends AppCompatActivity {

    ActivityProducDetailBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityProducDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Get references to views
        TextView detailCategoryName = findViewById(R.id.textView);
        ImageView detailCategoryImage = findViewById(R.id.imageView);

        // Get data from intent
        String categoryName = getIntent().getStringExtra("categoryName");
        int categoryImageResId = getIntent().getIntExtra("categoryImage", -1);

        // Set data to views
        detailCategoryName.setText(categoryName);
        detailCategoryImage.setImageResource(categoryImageResId);

    }
}