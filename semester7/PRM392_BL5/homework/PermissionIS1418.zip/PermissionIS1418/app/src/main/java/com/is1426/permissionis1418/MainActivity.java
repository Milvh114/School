package com.is1426.permissionis1418;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    Button btnRecord;
    TextView txtInfo;

    private void bindingView() {
        btnRecord = findViewById(R.id.btnRecord);
        txtInfo = findViewById(R.id.txtInfo);
    }

    private void bindingAction() {
        btnRecord.setOnClickListener(this::onBtnRecordClick);
    }

    private void onBtnRecordClick(View view) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            if (shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO)) {
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setMessage("TÔi cần cái quyền Microphone để ghi âm từ mic, bạn cấp cho tôi nhé")
                        .setTitle("Yêu cầu quyền ghi âm từ Micro")
                        .setPositiveButton("OK", (DialogInterface dialogInterface, int i) -> {
                            requestPermission();
                        }).create().show();

            } else {
                Toast.makeText(this, "Lần đầu!", Toast.LENGTH_SHORT).show();
                requestPermission();
            }

        }else{
            doActionRecord();
        }
    }

    private void doActionRecord() {
        Toast.makeText(this, "Recording in progress!", Toast.LENGTH_SHORT).show();
    }


    private final int REQUEST_CODE_FOR_REQUEST_PERMISSION = 1;

    private void requestPermission() {
        String[] permissions = {
                Manifest.permission.RECORD_AUDIO, // Quyền micro
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
        };
        ActivityCompat.requestPermissions(this, permissions, REQUEST_CODE_FOR_REQUEST_PERMISSION);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case REQUEST_CODE_FOR_REQUEST_PERMISSION:
                txtInfo.setText(Arrays.toString(permissions) + " <--> " + Arrays.toString(grantResults));
                if(grantResults[0]==PackageManager.PERMISSION_GRANTED){
                    doActionRecord();
                }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bindingView();
        bindingAction();
    }
}